{-# LANGUAGE OverloadedStrings #-}
module Main (main) where

import Lib
import Data.Text (Text)
import qualified Data.Text as T
import Data.Aeson (Value(..), object, (.=), toJSON) -- Added `toJSON` import
import qualified Data.Aeson.Key as Key
import qualified Data.Text.Encoding as TE
import qualified Data.Text.Encoding as TE
import qualified Data.Aeson as Aeson

-- Custom data types for different value types
data MyValue = MyDate (Int, Int, Int) | MyNumber Integer | MyString Text | MyBool Bool deriving Show

-- Parse a single key-value pair
-- parseEntity :: Text -> Maybe (Text, MyValue)
-- parseEntity pair = case T.splitOn "|" pair of
--     [key, value] -> case T.unpack $ T.take 2 key of
--         "#00" -> (\d -> (key, MyDate d)) <$> parseDate value
--         "#01" -> Just (key, MyNumber . read . T.unpack $ value) -- Changed to `Just`
--         "#02" -> Just (key, MyString value) -- Changed to `Just`
--         "#03" -> Just (key, MyBool . readBool . T.unpack $ value) -- Changed to `Just`
--         _     -> Nothing
--     _            -> Nothing
--     where 
--         parseDate s = case map T.unpack (T.splitOn "-" s) of
--             [y, m, d] -> Just (read y, read m, read d)
--             _         -> Nothing
--         readBool "Y" = True
--         readBool "y" = True
--         readBool "T" = True
--         readBool "t" = True
--         readBool _   = False

-- Parse the encoded string to JSON object
parseToJSON :: Text -> Maybe [Text]
parseToJSON input = do
    let pairs = T.splitOn "#" input
    return pairs
    -- entities <- traverse parseEntity pairs
    -- let keyValuePairs = map (\(key, val) -> TE.encodeUtf8 key .= val) entities
    -- return $ object keyValuePairs

-- Example input string
input :: Text
input = "#00date|1997-02-06#02name|bob#01age|20#03hasPassport|Y"

main :: IO ()
main = case parseToJSON input of
    Just json -> print json
    Nothing   -> putStrLn "Failed to parse input string"
